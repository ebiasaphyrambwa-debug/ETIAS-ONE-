function generatePairingCode() {
  const phone = document.getElementById("phoneInput").value.trim();
  const output = document.getElementById("codeOutput");

  if (!phone.match(/^[0-9]{10,15}$/)) {
    output.style.color = "red";
    output.textContent = "❌ Invalid phone number format.";
    return;
  }

  const code = "ETIAS-" + Math.floor(100000 + Math.random() * 900000);
  output.style.color = "#00ffcc";
output.textContent = `✅ Your pairing code:{code}`;
}
```


